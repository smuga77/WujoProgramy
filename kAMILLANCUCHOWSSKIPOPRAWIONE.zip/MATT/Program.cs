﻿using System;
using System.IO;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            double result = 0.0;
            MathText.ReversePolishNotation rpn = new MathText.ReversePolishNotation();
            string expression;
            Console.Write("Wprowadź Dane: ");
            expression = Console.ReadLine();
            rpn.Parse(expression);
            result = rpn.Evaluate();
            Console.WriteLine("Dane wprowadzone:   {0}", rpn.OriginalExpression);
            Console.WriteLine("Dane zapisane w RPN:   {0}", rpn.PostfixExpression);
            Console.WriteLine("wynik: {0}", result);

            Console.WriteLine("Koniec programu");
            Console.ReadLine();
        }
    }
}
